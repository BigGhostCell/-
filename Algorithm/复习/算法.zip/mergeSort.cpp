#include<iostream>
#include<vector>
#include <cstdlib>
#include <ctime>
using namespace std;
int n;
vector<int> nums;
vector<int> output;
vector<vector<int>> result;
vector<bool> visited;

void backTrack(int cnt)
{
	if (cnt == n)
	{
		result.push_back(output);
		return;
	}
		
	for (int i = 0; i < n; i++)
	{
		if (visited[i] == false)
		{
			visited[i] = true;
			output.push_back(nums[i]);
			backTrack(cnt+1);
			output.pop_back();
			visited[i] = false;
		}
		
	}
}

int main()
{
	
	cin >> n;//�����С 
	nums.resize(n);//����һ��nums���飬��СΪn����ʼֵΪ0

	for (int i = 0; i < n; i++)
	{
		nums[i] = i;//��ʼ�� 
	}
	visited.resize(n, false);

	backTrack(0);

	for (int i = 0; i < result.size(); i++)
	{
		for (int j = 0; j < result[0].size(); j++)
		{
			cout << result[i][j] << "  ";
		}
		cout << "\n";
	}
}
