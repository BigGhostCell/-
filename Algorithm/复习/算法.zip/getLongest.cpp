#include<iostream>
#include<string>
#include<vector>

using namespace std;

int getLongest(string S1, string S2)
{
	int len1 = S1.size();
	int len2 = S2.size();
	int maxLen = 0;
	vector<vector<int>> dp(len1+1, vector<int>(len2+1, 0));
	
	for(int i = 1; i <= len1; i++)
	{
		for(int j = 1; j <= len2; j++)
		{
			if(S1[i-1] == S2[j-1])
			{
				dp[i][j] = dp[i-1][j-1] + 1;
				maxLen = max(dp[i][j], maxLen);
			}
		}
	 } 
	 return maxLen;
}

int main()
{
	string S1, S2;
	getline(cin, S1);
	getline(cin, S2);
	cout << getLongest(S1, S2);
	
 } 
